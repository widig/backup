//// [ClassDeclaration14.ts]
class C {
   foo();
   constructor();
}

//// [ClassDeclaration14.js]
var C = (function () {
    function C() {
    }
    return C;
}());
