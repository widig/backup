//// [ArrowFunction1.ts]
var v = (a: ) => {
   
};

//// [ArrowFunction1.js]
var v = function (a) {
};
