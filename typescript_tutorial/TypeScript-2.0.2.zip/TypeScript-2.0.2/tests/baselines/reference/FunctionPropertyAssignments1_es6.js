//// [FunctionPropertyAssignments1_es6.ts]
var v = { *foo() { } }

//// [FunctionPropertyAssignments1_es6.js]
var v = { foo: function () { } };
