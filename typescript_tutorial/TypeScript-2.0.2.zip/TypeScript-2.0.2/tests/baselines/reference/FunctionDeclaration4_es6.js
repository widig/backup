//// [FunctionDeclaration4_es6.ts]
function yield() {
}

//// [FunctionDeclaration4_es6.js]
function yield() {
}
