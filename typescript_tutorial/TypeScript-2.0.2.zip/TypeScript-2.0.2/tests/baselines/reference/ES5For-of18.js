//// [ES5For-of18.ts]
for (let v of []) {
    v;
}
for (let v of []) {
    v;
}


//// [ES5For-of18.js]
for (var _i = 0, _a = []; _i < _a.length; _i++) {
    var v = _a[_i];
    v;
}
for (var _b = 0, _c = []; _b < _c.length; _b++) {
    var v = _c[_b];
    v;
}
