//// [FunctionDeclaration6.ts]
{
    function foo();
    function bar() { }
}

//// [FunctionDeclaration6.js]
{
    function bar() { }
}
