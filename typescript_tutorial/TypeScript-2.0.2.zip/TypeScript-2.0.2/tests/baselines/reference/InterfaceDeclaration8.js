//// [InterfaceDeclaration8.ts]
interface string {
}

//// [InterfaceDeclaration8.js]
