//// [FunctionDeclaration8_es6.ts]
var v = { [yield]: foo }

//// [FunctionDeclaration8_es6.js]
var v = (_a = {}, _a[yield] = foo, _a);
var _a;
