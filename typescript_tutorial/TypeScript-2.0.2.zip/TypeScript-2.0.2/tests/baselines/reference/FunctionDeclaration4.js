//// [FunctionDeclaration4.ts]
function foo();
function bar() { }

//// [FunctionDeclaration4.js]
function bar() { }
