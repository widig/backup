//// [FunctionDeclaration1_es6.ts]
function * foo() {
}

//// [FunctionDeclaration1_es6.js]
function foo() {
}
