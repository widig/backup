//// [ES5For-ofTypeCheck12.ts]
for (const v of 0) { }

//// [ES5For-ofTypeCheck12.js]
for (var _i = 0, _a = 0; _i < _a.length; _i++) {
    var v = _a[_i];
}
