//// [FunctionExpression1_es6.ts]
var v = function * () { }

//// [FunctionExpression1_es6.js]
var v = function () { };
