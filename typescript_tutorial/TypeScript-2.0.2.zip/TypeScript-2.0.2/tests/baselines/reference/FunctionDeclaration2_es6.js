//// [FunctionDeclaration2_es6.ts]
function f(yield) {
}

//// [FunctionDeclaration2_es6.js]
function f(yield) {
}
