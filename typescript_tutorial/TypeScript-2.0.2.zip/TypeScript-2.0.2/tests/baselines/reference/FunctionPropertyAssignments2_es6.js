//// [FunctionPropertyAssignments2_es6.ts]
var v = { *() { } }

//// [FunctionPropertyAssignments2_es6.js]
var v = { : function () { } };
