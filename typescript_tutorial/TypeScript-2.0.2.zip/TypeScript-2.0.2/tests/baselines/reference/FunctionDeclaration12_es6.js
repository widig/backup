//// [FunctionDeclaration12_es6.ts]
var v = function * yield() { }

//// [FunctionDeclaration12_es6.js]
var v = , yield = function () { };
