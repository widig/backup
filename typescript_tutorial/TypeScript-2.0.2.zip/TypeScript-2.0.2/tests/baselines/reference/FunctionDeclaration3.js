//// [FunctionDeclaration3.ts]
function foo();

//// [FunctionDeclaration3.js]
