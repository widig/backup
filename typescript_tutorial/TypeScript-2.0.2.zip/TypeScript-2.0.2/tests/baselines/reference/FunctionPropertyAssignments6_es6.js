//// [FunctionPropertyAssignments6_es6.ts]
var v = { *<T>() { } }

//// [FunctionPropertyAssignments6_es6.js]
var v = { : function () { } };
