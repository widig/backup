//// [FunctionPropertyAssignments4_es6.ts]
var v = { * }

//// [FunctionPropertyAssignments4_es6.js]
var v = { : function () { } };
