//// [ArrowFunction3.ts]
var v = (a): => {
   
};

//// [ArrowFunction3.js]
var v = function (a) {
};
