//// [FunctionDeclaration5_es6.ts]
function*foo(yield) {
}

//// [FunctionDeclaration5_es6.js]
yield;
{
}
