//// [ES5For-of25.ts]
var a = [1, 2, 3];
for (var v of a) {
    v;
    a;
}

//// [ES5For-of25.js]
var a = [1, 2, 3];
for (var _i = 0, a_1 = a; _i < a_1.length; _i++) {
    var v = a_1[_i];
    v;
    a;
}
//# sourceMappingURL=ES5For-of25.js.map