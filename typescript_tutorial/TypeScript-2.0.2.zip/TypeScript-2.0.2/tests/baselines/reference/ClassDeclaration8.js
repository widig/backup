//// [ClassDeclaration8.ts]
class C {
  constructor();
}

//// [ClassDeclaration8.js]
var C = (function () {
    function C() {
    }
    return C;
}());
