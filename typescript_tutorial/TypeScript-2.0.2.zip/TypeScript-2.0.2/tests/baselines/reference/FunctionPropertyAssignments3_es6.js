//// [FunctionPropertyAssignments3_es6.ts]
var v = { *{ } }

//// [FunctionPropertyAssignments3_es6.js]
var v = { : function () { } };
