//// [ES5For-of5.ts]
for (var _a of []) {
    var x = _a;
}

//// [ES5For-of5.js]
for (var _i = 0, _b = []; _i < _b.length; _i++) {
    var _a = _b[_i];
    var x = _a;
}
