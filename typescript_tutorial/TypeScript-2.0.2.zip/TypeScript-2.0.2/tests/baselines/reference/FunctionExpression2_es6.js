//// [FunctionExpression2_es6.ts]
var v = function * foo() { }

//// [FunctionExpression2_es6.js]
var v = function foo() { };
