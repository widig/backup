# The TypeScript Wiki

To read the wiki, [visit the wiki on GitHub](https://github.com/Microsoft/TypeScript/wiki).

To contribute by filing an issue or sending a pull request, [visit the wiki repository](https://github.com/Microsoft/TypeScript-wiki).

