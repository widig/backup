class foo {
    constructor(n?: number, m? = 5, o?: string = "") { }
    x: number = 1 ? 2 : 3;
}
