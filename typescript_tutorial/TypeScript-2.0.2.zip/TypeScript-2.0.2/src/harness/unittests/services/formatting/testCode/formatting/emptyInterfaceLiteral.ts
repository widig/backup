    function    foo  (  x  :    {    }    )    {    }

foo    (  {     }   )    ;


    
            interface    bar    {
                x   :    {     }   ;
       y  :       (         )    =>    {     }   ;   
                                                    }