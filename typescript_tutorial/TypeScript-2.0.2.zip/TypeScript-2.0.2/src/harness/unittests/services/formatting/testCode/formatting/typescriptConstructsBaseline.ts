module MyModule {
    module A.B.C {
        module F {
        }
    }
    interface Blah {
        boo: string;
    }

    class Foo {

    }

    class Foo2 {
        public foo(): number {
            return 5 * 6;
        }
        public foo2() {
            if (1 === 2) {
                var y: number = 76;
                return y;
            }

            while (2 == 3) {
                if (y == null) {

                }
            }
        }

        public foo3() {
            if (1 === 2)

                //comment preventing line merging
            {
                var y = 76;
                return y;
            }

        }
    }
}

function foo(a: number, b: number): number {
    return 0;
}

function bar(a: number, b: number): number[] {
    return [];
}

module BugFix3 {
    declare var f: {
        (): any;
        (x: number): string;
        foo: number;
    };
}
