module Foo {
}

import bar  =    Foo;

import bar2=Foo;
