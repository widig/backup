# Read this!

The files within this directory are used to generate `lib.d.ts` and `lib.es6.d.ts`.

## Generated files

Any files ending in `.generated.d.ts` aren't mean to be edited by hand.
If you need to make changes to such files, make a change to the input files for our [library generator](https://github.com/Microsoft/TSJS-lib-generator).
