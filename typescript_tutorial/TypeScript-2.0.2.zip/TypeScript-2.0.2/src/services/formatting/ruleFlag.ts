///<reference path='references.ts' />


/* @internal */
namespace ts.formatting {
    export const enum RuleFlags {
        None,
        CanDeleteNewLines
    }
}